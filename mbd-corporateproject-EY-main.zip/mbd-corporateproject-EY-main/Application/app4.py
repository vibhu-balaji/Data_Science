# app.py — Gemini-Powered PE Chatbot with Horizontal Top Navigation

import os
import streamlit as st
import pandas as pd
import joblib
import re
from difflib import get_close_matches
from sentence_transformers import SentenceTransformer, util
from catboost import CatBoostClassifier
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_core.documents import Document
from langchain_core.prompts import PromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from collections import Counter
import networkx as nx
import requests

# === Page Configuration and Custom Styling ===
st.set_page_config(page_title="PE Chatbot", page_icon="��", layout="wide")

# Hide sidebar and optimize chat layout
st.markdown("""
    <style>
        [data-testid="stSidebar"] {
            display: none;
        }

        .block-container {
            padding-top: 0rem !important;
            padding-bottom: 0rem !important;
            max-width: 100%;
        }

        .stTabs [data-baseweb="tab-list"] {
            margin-top: 0rem;
            padding-top: 0.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid #eee;
            position: relative;
            z-index: 10;
        }

        .stTabs [data-baseweb="tab"] {
            font-size: 1.05rem;
            padding: 0.5rem 1rem;
        }

        header {
            visibility: hidden;
        }

        .stChatInputContainer {
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            z-index: 100;
            background: white;
            border-top: 1px solid #eee;
            padding: 1rem;
        }

        .main .block-container {
            padding-bottom: 100px;
        }
    </style>
""", unsafe_allow_html=True)

# === Tab Layout ===
tab1, tab2, tab3, tab_drilldown, tab_upload = st.tabs([
    "💬 Chatbot", "🔍 Explorer", "📄 Report", "🔎 Drilldown Analytics", "⬆️ Upload & Enrich"
])

# === Environment Setup ===
load_dotenv()
os.environ["GOOGLE_API_KEY"] = os.getenv("GOOGLE_API_KEY")

# === Load Models & Data ===
try:
    catboost_model = joblib.load("ML/Supervised/CatBoost.pkl")
except Exception as e:
    st.error(f"❌ Error loading CatBoost model: {str(e)}")
    st.stop()

@st.cache_resource(show_spinner="Loading SentenceTransformer model...")
def load_sbert_model():
    return SentenceTransformer("all-MiniLM-L6-v2", device='cpu')
try:
    sbert_model = load_sbert_model()
except Exception as e:
    st.error(f"❌ Error loading SentenceTransformer model: {str(e)}")
    st.info("🔄 This might take a few minutes on first run...")
    st.stop()

@st.cache_resource(show_spinner="Loading HuggingFace Embeddings...")
def load_hf_embeddings():
    return HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2", model_kwargs={"device": "cpu"})
try:
    embedding_model = load_hf_embeddings()
except Exception as e:
    st.error(f"❌ Error loading HuggingFace embeddings: {str(e)}")
    st.stop()

try:
    pe_df = pd.read_excel("Data/Processed/Cleaned_PE.xlsx")
except Exception as e:
    st.error(f"❌ Error loading PE data: {str(e)}")
    st.stop()

try:
    company_df = pd.read_excel("Data/Processed/outputcheckcombined2.xlsx")
except Exception as e:
    st.error(f"❌ Error loading company data: {str(e)}")
    st.stop()

# === Helper Functions ===
def normalize_company_sectors(row):
    cols = ['1º_characterization', '2º_characterization', '3º_characterization',
            '4º_characterization', '5º_characterization', '6º_characterization']
    return [str(row[col]).strip().lower() for col in cols if pd.notna(row[col])]

def embedding_sector_similarity_score(row):
    cs_embeddings = row['sector_embeddings_x']
    ps_embeddings = row['sector_embeddings_y']
    if cs_embeddings is None or ps_embeddings is None:
        return 0
    cosine_scores = util.cos_sim(cs_embeddings, ps_embeddings)
    return cosine_scores.max().item()

def ebitda_match(row):
    try:
        ebitda = float(row.get('ebitda_lya', None))
        min_val = row.get('ticket_ebitda_min', None)
        max_val = row.get('ticket_ebitda_max', None)
        if pd.isna(ebitda): return False
        if pd.notna(min_val) and pd.notna(max_val): return min_val <= ebitda <= max_val
        if pd.notna(min_val): return ebitda >= min_val
        if pd.notna(max_val): return ebitda <= max_val
        return False
    except: return False

def build_pe_list_string(top_matches_df):
    lines = []
    for _, row in top_matches_df.iterrows():
        line = f"- {row['pe']}: Match Probability {row['match_probability']:.2f}, Sector Similarity {row['sector_similarity_score']:.2f}, "
        line += f"EBITDA Match {'Yes' if row['ebitda_in_range'] else 'No'}, Spanish Companies: {int(row['total_spanish_companies'])}"
        lines.append(line)
    return "\n".join(lines)

def pe_firm_to_text(row):
    return f"""Firm: {row['pe']}
Sectors: {row.get('sectors', 'N/A')}
Top Geographies: {row.get('top_geographies', 'N/A')}
Total Spanish Companies: {row.get('total_spanish_companies', 'N/A')}
Total Spanish Divested Companies: {row.get('total_spanish_divested_companies', 'N/A')}"""

def get_pe_context(top_pe_names):
    """Get context about PE firms without using vectorstore"""
    context_lines = []
    for pe_name in top_pe_names:
        pe_info = pe_df[pe_df['pe'] == pe_name]
        if not pe_info.empty:
            row = pe_info.iloc[0]
            context = f"""Firm: {row['pe']}
Sectors: {row.get('sectors', 'N/A')}
Top Geographies: {row.get('top_geographies', 'N/A')}
Total Spanish Companies: {row.get('total_spanish_companies', 'N/A')}
Total Spanish Divested Companies: {row.get('total_spanish_divested_companies', 'N/A')}"""
            context_lines.append(context)
    return "\n\n".join(context_lines)

# === Retrieval Setup ===
try:
    pe_chunks = pe_df.apply(pe_firm_to_text, axis=1).tolist()
    documents = [Document(page_content=chunk, metadata={}) for chunk in pe_chunks]
    vectorstore = Chroma.from_documents(documents, embedding_model, persist_directory="./chroma_db")
    retriever = vectorstore.as_retriever(search_kwargs={"k": 10})
except Exception as e:
    vectorstore = None
    retriever = None

# === LLM Setup ===
llm = ChatGoogleGenerativeAI(model="gemini-2.5-pro", temperature=0.2)

# Main RAG prompt for initial analysis
rag_prompt = PromptTemplate.from_template("""
You are a Private Equity strategy advisor at EY.

You have access to:
- A ranked list of PE firms from a machine learning model.
- Background information on each firm including sectors, geographies, divestments, and investment patterns.

Company:
- Name: {company_name}
- Sector: {company_sector}
- EBITDA: €{company_ebitda}M

Top PE Matches:
{pe_list}

Background Knowledge:
{retrieved_context}

Each firm includes its sector similarity score, EBITDA compatibility, Spanish presence, and match probability.

👉 Please explain in **bullet points only** why these firms are recommended. Use both the ML scores and the retrieved PE firm context to support your reasoning.
👉 **Do not use headers, dates, or email-style formatting.**
👉 Focus on deal rationale in concise, executive language.
""")

# Q&A prompt for follow-up questions
qa_rag_prompt = PromptTemplate.from_template("""
You are a Private Equity expert answering an EY consultant's question.

Context:
- Company: {company_name}
- Sector: {company_sector}
- EBITDA: €{company_ebitda}M
- Selected PE firms: {pe_list}

Background Information:
{retrieved_context}

Conversation history:
{chat_history}

Latest question:
{user_question}

Respond clearly, very briefly and concise and with specific reasoning. Only answer to the specific question asked.
""")

# Create simple chain functions instead of LLMChain
def run_rag_chain(inputs):
    try:
        formatted_prompt = rag_prompt.format(**inputs)
        response = llm.invoke(formatted_prompt)
        return response.content
    except Exception as e:
        return f"Error generating response: {str(e)}"

def run_qa_chain(inputs):
    try:
        formatted_prompt = qa_rag_prompt.format(**inputs)
        response = llm.invoke(formatted_prompt)
        return response.content
    except Exception as e:
        return f"Error generating response: {str(e)}"

# === Prediction Logic ===
def predict_top_pes(company_name, top_n=10):
    selected = company_df[company_df["company_name"].str.lower() == company_name.lower()]
    if selected.empty: return None, "❌ Company not found."
    selected["key"] = 1
    pe_copy = pe_df.copy(); pe_copy["key"] = 1
    df = selected.merge(pe_copy, on="key").drop("key", axis=1)
    df["total_spanish_companies"] = df["total_spanish_companies"].fillna(0)
    df["normalized_sectors_x"] = df.apply(normalize_company_sectors, axis=1)
    df["normalized_sectors_y"] = df["sectors"].fillna('').apply(lambda x: [s.strip().lower() for s in x.split(",") if s])
    df["sector_embeddings_x"] = df["normalized_sectors_x"].apply(sbert_model.encode)
    df["sector_embeddings_y"] = df["normalized_sectors_y"].apply(sbert_model.encode)
    df["sector_similarity_score"] = df.apply(embedding_sector_similarity_score, axis=1)
    df["ebitda_in_range"] = df.apply(ebitda_match, axis=1)
    df["match_probability"] = catboost_model.predict_proba(
        df[["sector_similarity_score", "ebitda_in_range", "total_spanish_companies"]])[:, 1]
    return df.sort_values("match_probability", ascending=False).head(top_n), None

# === TAB 1: PE Chatbot ===
#=== TAB 1: PE Chatbot ===
with tab1:
    st.title("💼 PE Strategy Advisor")

    # Session state
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "qa_context" not in st.session_state:
        st.session_state.qa_context = None

    # Render chat history (user and assistant)
    for idx, msg in enumerate(st.session_state.messages):
        with st.chat_message(msg["role"]):
            # Show results table if present (before text)
            if msg.get("results_table") is not None:
                st.dataframe(msg["results_table"])
            st.markdown(msg["content"])

            # Feedback buttons for assistant messages
            if msg["role"] == "assistant":
                st.markdown("#### Was this answer helpful?")
                col1, col2 = st.columns([1, 1])
                with col1:
                    if st.button("👍 Yes", key=f"yes_{idx}"):
                        st.success("Thanks for your feedback!")
                with col2:
                    if st.button("👎 No", key=f"no_{idx}"):
                        st.warning("Thanks — we'll use that to improve.")

    # Chat input at the bottom
    user_input = st.chat_input("Ask about PE firms for a company or follow up...")

    if user_input:
        # Add user message
        st.session_state.messages.append({"role": "user", "content": user_input})

        # Show loading spinner
        with st.spinner("🔍 Analyzing your request..."):
            # Always try to match company name first
            company_df_clean = company_df[company_df["company_name"].notna()].copy()
            company_df_clean["__clean__"] = company_df_clean["company_name"].astype(str).str.lower().str.strip()
            clean_names = company_df_clean["__clean__"].tolist()
            user_clean = user_input.lower().strip()
            
            # Debug: Show what we're looking for
            st.write(f"🔍 Looking for: '{user_clean}'")
            st.write(f"📊 Available companies (first 5): {clean_names[:5]}")
            
            candidates = get_close_matches(user_clean, clean_names, n=1, cutoff=0.6)
            
            # If no exact match, try token matching
            if not candidates:
                input_tokens = re.findall(r'\b\w+\b', user_clean)
                st.write(f"🔍 Trying tokens: {input_tokens}")
                for token in input_tokens:
                    token_matches = get_close_matches(token, clean_names, n=1, cutoff=0.8)
                    if token_matches:
                        candidates = token_matches
                        st.write(f"✅ Found match via token '{token}': {token_matches[0]}")
                        break

            if candidates:
                # Company found - treat as new company query
                matched_name = company_df_clean[company_df_clean["__clean__"] == candidates[0]]["company_name"].iloc[0]
                st.write(f"🎯 Matched company: {matched_name}")
                
                top_df, error = predict_top_pes(matched_name, top_n=10)
                if error:
                    response = error
                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": response
                    })
                else:
                    top_df = top_df.head(10)
                    pe_list = build_pe_list_string(top_df)
                    top_pe_names = top_df["pe"].tolist()
                    
                    # Use fallback method (avoiding ChromaDB issues)
                    retrieved_text = get_pe_context(top_pe_names)
                    rag_inputs = {
                        "company_name": matched_name,
                        "company_sector": ", ".join(top_df.iloc[0]["normalized_sectors_x"]),
                        "company_ebitda": top_df.iloc[0]["ebitda_lya"],
                        "pe_list": pe_list,
                        "retrieved_context": retrieved_text
                    }
                    response = run_rag_chain(rag_inputs)
                    results_table = top_df[["pe", "match_probability", "ebitda_in_range",
                                            "total_spanish_companies", "sector_similarity_score"]].copy()
                    results_table.columns = ["PE Firm", "Match Probability", "EBITDA in Range",
                                            "Spanish Companies", "Sector Similarity"]
                    # Store context for follow-up Q&A
                    st.session_state.qa_context = {
                        "company_name": matched_name,
                        "company_sector": ", ".join(top_df.iloc[0]["normalized_sectors_x"]),
                        "company_ebitda": top_df.iloc[0]["ebitda_lya"],
                        "pe_list": pe_list,
                        "retrieved_context": retrieved_text
                    }
                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": response + "\n\nAny follow-up questions?",
                        "results_table": results_table
                    })
            elif st.session_state.qa_context is not None:
                # No company match but we have context - treat as follow-up Q&A
                st.write("💬 Treating as follow-up question...")
                qa_inputs = {
                    **st.session_state.qa_context,
                    "chat_history": "\n".join(
                        [f"User: {m['content']}" for m in st.session_state.messages if m["role"] == "user"]
                    ),
                    "user_question": user_input,
                    "retrieved_context": st.session_state.qa_context["retrieved_context"]
                }
                response = run_qa_chain(qa_inputs)
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": response + "\n\nAny follow-up questions?",
                })
            else:
                # No company match and no context
                st.write("❌ No company match found")
                response = "❌ I couldn't recognize a valid company in your message. Please try typing the full company name."
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": response
                })
        st.rerun()

# === TAB 2: Explorer ===
with tab2:
    st.title("🔍 PE Data Explorer")
    st.markdown("### Interactive Analytics Dashboard for Private Equity Insights")

    # --- FILTERS (TOP OF PAGE, NOT SIDEBAR) ---
    st.markdown("#### Filter Data")
    colf1, colf2, colf3, colf4, colf5 = st.columns([2,2,2,2,1])
    with colf1:
        pe_firm_options = sorted(pe_df['pe'].dropna().unique())
        selected_pe_firms = st.multiselect("PE Firms", pe_firm_options, default=pe_firm_options[:5])
    with colf2:
        all_sectors = []
        for sectors in pe_df['sectors'].dropna():
            all_sectors.extend([s.strip().lower() for s in str(sectors).split(',') if s.strip()])
        sector_counts = Counter(all_sectors)
        top_sectors = [sector for sector, count in sector_counts.most_common(10)]
        selected_sectors = st.multiselect("Sectors", top_sectors, default=top_sectors[:3])
    with colf3:
        all_geos = []
        for geos in pe_df['top_geographies'].dropna():
            all_geos.extend([g.strip().lower() for g in str(geos).split(',') if g.strip()])
        geo_counts = Counter(all_geos)
        top_geos = [geo for geo, count in geo_counts.most_common(10)]
        selected_geographies = st.multiselect("Geographies", top_geos, default=top_geos[:3])
    with colf4:
        company_names = sorted(company_df['company_name'].dropna().unique())
        selected_companies = st.multiselect("Companies", company_names, default=company_names[:5])
    with colf5:
        if st.button("Reset All"):
            st.experimental_rerun()

    # --- FILTER DATA ---
    filtered_pe = pe_df.copy()
    if selected_pe_firms:
        filtered_pe = filtered_pe[filtered_pe['pe'].isin(selected_pe_firms)]
    if selected_sectors:
        filtered_pe = filtered_pe[filtered_pe['sectors'].fillna('').apply(lambda x: any(s in x.lower() for s in selected_sectors))]
    if selected_geographies:
        filtered_pe = filtered_pe[filtered_pe['top_geographies'].fillna('').apply(lambda x: any(g in x.lower() for g in selected_geographies))]
    filtered_companies = company_df.copy()
    if selected_companies:
        filtered_companies = filtered_companies[filtered_companies['company_name'].isin(selected_companies)]

    # --- METRICS ---
    st.markdown("---")
    st.markdown("#### Key Metrics")
    mcol1, mcol2, mcol3, mcol4 = st.columns(4)
    with mcol1:
        st.metric("Total PE Firms", f"{len(filtered_pe):,}", help="Number of PE firms after filtering.")
    with mcol2:
        avg_spanish = filtered_pe['total_spanish_companies'].mean() if not filtered_pe.empty else 0
        st.metric("Avg Spanish Companies", f"{avg_spanish:.1f}", help="Average number of Spanish companies per PE firm.")
    with mcol3:
        total_divested = filtered_pe['total_spanish_divested_companies'].sum() if not filtered_pe.empty else 0
        st.metric("Total Divested", f"{total_divested:,}", help="Total number of divested Spanish companies.")
    with mcol4:
        active_firms = len(filtered_pe[filtered_pe['total_spanish_companies'] > 0])
        st.metric("Active Firms", f"{active_firms:,}", help="PE firms with at least one Spanish company.")

    # --- WORLD MAP VISUALIZATION ---
    st.markdown("---")
    st.markdown("#### 🌍 Global Presence of PE Firms and Companies")
    # Prepare data for map
    geo_map_data = []
    for idx, row in filtered_pe.iterrows():
        for geo in str(row['top_geographies']).split(','):
            geo = geo.strip()
            if geo:
                geo_map_data.append({'Firm': row['pe'], 'Geography': geo, 'Type': 'PE Firm'})
    for idx, row in filtered_companies.iterrows():
        if 'country' in row and pd.notna(row['country']):
            geo_map_data.append({'Firm': row['company_name'], 'Geography': row['country'], 'Type': 'Company'})
    geo_map_df = pd.DataFrame(geo_map_data)
    if not geo_map_df.empty:
        fig_map = px.scatter_geo(
            geo_map_df,
            locations="Geography",
            locationmode="country names",
            color="Type",
            hover_name="Firm",
            title="PE Firms and Companies by Geography",
            projection="natural earth",
            opacity=0.7,
            height=500
        )
        fig_map.update_layout(margin={"r":0,"t":40,"l":0,"b":0}, legend_title_text='Entity Type')
        st.plotly_chart(fig_map, use_container_width=True)
    else:
        st.info("No geographic data available for selected filters.")

    # --- CHARTS & TABLES ---
    st.markdown("---")
    tab_overview, tab_firms, tab_companies, tab_advanced, tab_network, tab_insights, tab_quality, tab_scenario = st.tabs([
        "Overview", "PE Firms", "Companies", "Advanced Analytics", "Network Graph", "Automated Insights", "Data Quality", "Scenario Analysis"
    ])

    with tab_overview:
        ocol1, ocol2 = st.columns(2)
        with ocol1:
            st.markdown("**Top Sectors**")
            sector_df = pd.DataFrame(sector_counts.most_common(10), columns=['Sector', 'Count'])
            fig_sectors = px.bar(sector_df, x='Sector', y='Count', color='Count', color_continuous_scale='viridis', title="Top 10 Sectors")
            fig_sectors.update_xaxes(tickangle=45)
            st.plotly_chart(fig_sectors, use_container_width=True)
        with ocol2:
            st.markdown("**PE Firms by Geography**")
            geo_df = pd.DataFrame(geo_counts.most_common(10), columns=['Geography', 'Count'])
            fig_geo = px.bar(geo_df, x='Geography', y='Count', color='Count', color_continuous_scale='earth', title="Top Geographies")
            fig_geo.update_xaxes(tickangle=45)
            st.plotly_chart(fig_geo, use_container_width=True)

    with tab_firms:
        st.markdown("### PE Firm Comparison Table")
        comparison_cols = ['pe', 'total_spanish_companies', 'total_spanish_divested_companies']
        if 'sectors' in filtered_pe.columns:
            comparison_cols.append('sectors')
        if 'top_geographies' in filtered_pe.columns:
            comparison_cols.append('top_geographies')
        comparison_df = filtered_pe[comparison_cols].sort_values('total_spanish_companies', ascending=False)
        st.dataframe(comparison_df, use_container_width=True)
        st.markdown("### PE Firm Activity")
        if not filtered_pe.empty:
            fig_activity = px.bar(
                filtered_pe,
                x='pe',
                y=['total_spanish_companies', 'total_spanish_divested_companies'],
                barmode='group',
                title="Active vs Divested Companies by PE Firm"
            )
            fig_activity.update_xaxes(tickangle=45)
            st.plotly_chart(fig_activity, use_container_width=True)

    with tab_companies:
        st.markdown("### Company Table")
        st.dataframe(filtered_companies, use_container_width=True)
        st.markdown("### Company Distribution by Country")
        if 'country' in filtered_companies.columns and filtered_companies['country'].notna().sum() > 0:
            comp_geo_counts = filtered_companies['country'].value_counts().reset_index()
            comp_geo_counts.columns = ['Country', 'Company Count']
            if not comp_geo_counts.empty:
                fig_comp_geo = px.choropleth(
                    comp_geo_counts,
                    locations="Country",
                    locationmode="country names",
                    color="Company Count",
                    color_continuous_scale="Blues",
                    title="Companies by Country"
                )
                fig_comp_geo.update_layout(margin={"r":0,"t":40,"l":0,"b":0})
                st.plotly_chart(fig_comp_geo, use_container_width=True)
            else:
                st.info("No country data available for selected companies.")
        else:
            st.info("No country data available for selected companies. Showing demo chart.")
            demo_geo = pd.DataFrame({"Country": ["Spain", "UK", "France", "Germany"], "Company Count": [10, 7, 5, 3]})
            fig_demo = px.choropleth(
                demo_geo,
                locations="Country",
                locationmode="country names",
                color="Company Count",
                color_continuous_scale="Blues",
                title="Demo: Companies by Country"
            )
            fig_demo.update_layout(margin={"r":0,"t":40,"l":0,"b":0})
            st.plotly_chart(fig_demo, use_container_width=True)

    with tab_advanced:
        st.markdown("### Correlation Analysis")
        numeric_cols = ['total_spanish_companies', 'total_spanish_divested_companies']
        numeric_data = filtered_pe[numeric_cols].dropna()
        if len(numeric_data) > 1:
            correlation = numeric_data.corr()
            fig_corr = px.imshow(
                correlation,
                title="Correlation Matrix",
                color_continuous_scale='RdBu',
                aspect='auto'
            )
            st.plotly_chart(fig_corr, use_container_width=True)
        st.markdown("### Statistical Summary")
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("**Spanish Companies Statistics:**")
            if not filtered_pe.empty:
                st.dataframe(filtered_pe['total_spanish_companies'].describe())
        with col2:
            st.markdown("**Divested Companies Statistics:**")
            if not filtered_pe.empty:
                st.dataframe(filtered_pe['total_spanish_divested_companies'].describe())
        st.markdown("### Predictive Insights")
        # Always align metrics in a single row
        insight_cols = st.columns(3)
        total_companies = filtered_pe['total_spanish_companies'].sum() if not filtered_pe.empty else 0
        total_divested = filtered_pe['total_spanish_divested_companies'].sum() if not filtered_pe.empty else 0
        divestment_rate = (total_divested / (total_companies + total_divested)) * 100 if (total_companies + total_divested) > 0 else 0
        with insight_cols[0]:
            st.metric("Total Portfolio Companies", f"{total_companies:,}")
        with insight_cols[1]:
            st.metric("Total Divestments", f"{total_divested:,}")
        with insight_cols[2]:
            st.metric("Divestment Rate", f"{divestment_rate:.1f}%")

    # --- Network Graph Tab ---
    with tab_network:
        st.markdown("### 🕸️ Interactive Network Graph")
        st.info("This network visualizes relationships between PE firms (from Cleaned_PE.xlsx) and companies (from outputcheckcombined2.xlsx) based on the 'owner' field. Only exact matches are shown. If you see isolated nodes, it means no companies are linked to those PE firms by name.")
        # Build a simple bipartite graph: PE firm <-> Company
        G = nx.Graph()
        pe_sample = filtered_pe['pe'].dropna().unique()[:10]
        relationship_rows = []
        for pe in pe_sample:
            G.add_node(pe, type='PE Firm')
            companies = company_df[company_df['owner'].str.strip().str.lower() == pe.strip().lower()]['company_name'] if 'owner' in company_df.columns else []
            for c in companies:
                G.add_node(c, type='Company')
                G.add_edge(pe, c)
                relationship_rows.append({'PE Firm': pe, 'Company': c})
        if G.number_of_edges() > 0:
            pos = nx.spring_layout(G, seed=42)
            edge_x, edge_y = [], []
            for edge in G.edges():
                x0, y0 = pos[edge[0]]
                x1, y1 = pos[edge[1]]
                edge_x += [x0, x1, None]
                edge_y += [y0, y1, None]
            edge_trace = go.Scatter(x=edge_x, y=edge_y, line=dict(width=0.5, color='#888'), hoverinfo='none', mode='lines')
            node_x, node_y, node_text, node_color = [], [], [], []
            for node in G.nodes():
                x, y = pos[node]
                node_x.append(x)
                node_y.append(y)
                node_text.append(node)
                node_color.append('#636EFA' if G.nodes[node]['type']=='PE Firm' else '#00CC96')
            node_trace = go.Scatter(x=node_x, y=node_y, mode='markers+text', text=node_text, textposition='top center',
                marker=dict(size=14, color=node_color, line_width=2), hoverinfo='text')
            fig = go.Figure(data=[edge_trace, node_trace], layout=go.Layout(
                showlegend=False, hovermode='closest', margin=dict(b=20,l=5,r=5,t=40),
                xaxis=dict(showgrid=False, zeroline=False), yaxis=dict(showgrid=False, zeroline=False),
                title="PE Firm - Company Network (sample)", height=600))
            st.plotly_chart(fig, use_container_width=True)
            st.markdown("**Legend:** <span style='color:#636EFA'>●</span> PE Firm, <span style='color:#00CC96'>●</span> Company", unsafe_allow_html=True)
            st.markdown("#### PE Firm - Company Relationships Table")
            st.dataframe(pd.DataFrame(relationship_rows), use_container_width=True)
        else:
            st.warning("No relationships found between PE firms and companies based on the 'owner' field. Try checking your data for matching names.")

    # --- Automated Insights Tab ---
    with tab_insights:
        st.markdown("### 🤖 Automated Insights & Anomaly Detection")
        st.info("Key findings and anomalies in your filtered data. Insights are based on Cleaned_PE.xlsx.")
        # Example: High divestment rate
        if not filtered_pe.empty:
            high_divest = filtered_pe[filtered_pe['total_spanish_divested_companies'] > filtered_pe['total_spanish_companies'] * 0.7]
            if not high_divest.empty:
                st.warning(f"Firms with unusually high divestment rates: {', '.join(high_divest['pe'])}")
            else:
                st.success("No firms with unusually high divestment rates detected.")
            # Example: Inactive firms
            inactive = filtered_pe[filtered_pe['total_spanish_companies'] == 0]
            if not inactive.empty:
                st.warning(f"Inactive firms (no Spanish companies): {', '.join(inactive['pe'])}")
            else:
                st.success("All firms have at least one Spanish company.")
            # Example: Outliers in company count
            mean_comp = filtered_pe['total_spanish_companies'].mean()
            outliers = filtered_pe[filtered_pe['total_spanish_companies'] > mean_comp * 2]
            if not outliers.empty:
                st.info(f"Firms with unusually high number of Spanish companies: {', '.join(outliers['pe'])}")
        else:
            st.info("No data to analyze.")

    # --- Data Quality Tab ---
    with tab_quality:
        st.markdown("### 🧹 Data Quality & Coverage Dashboard")
        st.info("This table shows the percentage of missing values for each field in your company data (from outputcheckcombined2.xlsx). Use this to identify data gaps and prioritize cleaning.")
        key_fields = ['company_name', 'owner', 'transaction_year', '1º_characterization', 'ebitda_lya']
        quality = {col: company_df[col].isna().mean() for col in key_fields if col in company_df.columns}
        st.markdown("#### Missing Data Percentage (Company Data: outputcheckcombined2.xlsx)")
        st.table(pd.DataFrame(list(quality.items()), columns=['Field', 'Missing %']).assign(**{'Missing %': lambda df: (df['Missing %']*100).round(1)}))
        st.markdown(f"#### Total Companies: {len(company_df)} (from outputcheckcombined2.xlsx)")
        # Optionally show PE data quality
        st.markdown("#### Missing Data Percentage (PE Firm Data: Cleaned_PE.xlsx)")
        pe_fields = ['pe', 'sectors', 'top_geographies', 'total_spanish_companies', 'total_spanish_divested_companies']
        pe_quality = {col: pe_df[col].isna().mean() for col in pe_fields if col in pe_df.columns}
        st.table(pd.DataFrame(list(pe_quality.items()), columns=['Field', 'Missing %']).assign(**{'Missing %': lambda df: (df['Missing %']*100).round(1)}))
        st.markdown(f"#### Total PE Firms: {len(pe_df)} (from Cleaned_PE.xlsx)")

    # --- Scenario Analysis Tab ---
    with tab_scenario:
        st.markdown("### 🔮 Scenario Analysis / What-If Tool")
        st.info("Simulate changes and see the impact on key metrics. This is a simulation only and does not affect your real data.")
        scenario = st.radio("Choose a scenario:", ["Divest all companies in a sector", "Add 10 companies to a PE firm"])
        if scenario == "Divest all companies in a sector":
            sector_options = sector_counts.keys()
            selected_sector = st.selectbox("Select Sector:", list(sector_options))
            temp_pe = filtered_pe.copy()
            affected = temp_pe[temp_pe['sectors'].fillna('').str.lower().str.contains(selected_sector)]
            temp_pe.loc[affected.index, 'total_spanish_divested_companies'] += temp_pe.loc[affected.index, 'total_spanish_companies']
            temp_pe.loc[affected.index, 'total_spanish_companies'] = 0
            st.markdown("#### Before / After Comparison")
            before = filtered_pe[['pe', 'total_spanish_companies', 'total_spanish_divested_companies']].copy()
            after = temp_pe[['pe', 'total_spanish_companies', 'total_spanish_divested_companies']].copy()
            st.markdown("**Before:**")
            st.dataframe(before, use_container_width=True)
            st.markdown("**After (Scenario):**")
            st.dataframe(after, use_container_width=True)
            st.metric("Total Divested (Scenario)", temp_pe['total_spanish_divested_companies'].sum(), help="Sum of divested companies after scenario.")
            st.metric("Active Companies (Scenario)", temp_pe['total_spanish_companies'].sum(), help="Sum of active companies after scenario.")
        else:
            pe_options = filtered_pe['pe'].unique().tolist()
            selected_pe = st.selectbox("Select PE Firm:", pe_options)
            temp_pe = filtered_pe.copy()
            temp_pe.loc[temp_pe['pe'] == selected_pe, 'total_spanish_companies'] += 10
            st.markdown("#### Before / After Comparison")
            before = filtered_pe[['pe', 'total_spanish_companies']].copy()
            after = temp_pe[['pe', 'total_spanish_companies']].copy()
            st.markdown("**Before:**")
            st.dataframe(before, use_container_width=True)
            st.markdown("**After (Scenario):**")
            st.dataframe(after, use_container_width=True)
            st.metric("Active Companies (Scenario)", temp_pe['total_spanish_companies'].sum(), help="Sum of active companies after scenario.")
            st.metric("Total PE Firms", len(temp_pe), help="Number of PE firms (unchanged in this scenario)")

    # --- EXPORT ---
    st.markdown("---")
    st.markdown("#### Export Data")
    expcol1, expcol2 = st.columns(2)
    with expcol1:
        csv_pe = filtered_pe.to_csv(index=False)
        st.download_button("Download Filtered PE Data (CSV)", csv_pe, "filtered_pe_data.csv", "text/csv")
    with expcol2:
        csv_comp = filtered_companies.to_csv(index=False)
        st.download_button("Download Filtered Company Data (CSV)", csv_comp, "filtered_company_data.csv", "text/csv")

    # --- FOOTER ---
    st.markdown("---")
    st.markdown("### 💡 How to Use This Explorer")
    st.markdown("""
    - **Filters**: Use the top filter bar to filter PE firms, sectors, geographies, and companies
    - **Tabs**: Navigate between different analysis views
    - **Interactive Charts**: Hover over charts for detailed information
    - **Data Tables**: Sort and explore detailed data
    - **Insights**: Look for patterns and trends in the data
    """)

# === TAB 3: Report ===
with tab3:
    st.title("📄 Executive Report Generator")
    st.markdown("""
    Generate a professional, branded report of your current analysis for sharing with clients or stakeholders.
    """)

    # --- Instructions ---
    st.info("""
    1. Review your filters and analytics in the Explorer tab.
    2. Add an executive summary or custom notes below.
    3. Click 'Generate Report' to create a PDF (or HTML) with all key metrics, charts, and tables.
    4. Download and share your report with confidence!
    """)

    # --- Executive Summary Input ---
    st.markdown("#### Executive Summary / Notes")
    exec_summary = st.text_area("Add a custom executive summary or notes for this report:",
                                placeholder="Write your executive summary here...",
                                height=120)

    # --- Preview Key Metrics ---
    st.markdown("#### Key Metrics Preview")
    mcol1, mcol2, mcol3, mcol4 = st.columns(4)
    with mcol1:
        st.metric("Total PE Firms", f"{len(filtered_pe):,}")
    with mcol2:
        avg_spanish = filtered_pe['total_spanish_companies'].mean() if not filtered_pe.empty else 0
        st.metric("Avg Spanish Companies", f"{avg_spanish:.1f}")
    with mcol3:
        total_divested = filtered_pe['total_spanish_divested_companies'].sum() if not filtered_pe.empty else 0
        st.metric("Total Divested", f"{total_divested:,}")
    with mcol4:
        active_firms = len(filtered_pe[filtered_pe['total_spanish_companies'] > 0])
        st.metric("Active Firms", f"{active_firms:,}")

    # --- Preview Main Charts (as thumbnails) ---
    st.markdown("#### Main Visuals Preview")
    colv1, colv2 = st.columns(2)
    with colv1:
        st.markdown("**PE Firms by Geography**")
        geo_map_data = []
        for idx, row in filtered_pe.iterrows():
            for geo in str(row['top_geographies']).split(','):
                geo = geo.strip()
                if geo:
                    geo_map_data.append({'Firm': row['pe'], 'Geography': geo, 'Type': 'PE Firm'})
        for idx, row in filtered_companies.iterrows():
            if 'country' in row and pd.notna(row['country']):
                geo_map_data.append({'Firm': row['company_name'], 'Geography': row['country'], 'Type': 'Company'})
        geo_map_df = pd.DataFrame(geo_map_data)
        fig_map = None
        if not geo_map_df.empty:
            fig_map = px.scatter_geo(
                geo_map_df,
                locations="Geography",
                locationmode="country names",
                color="Type",
                hover_name="Firm",
                title="PE Firms and Companies by Geography",
                projection="natural earth",
                opacity=0.7,
                height=300
            )
            fig_map.update_layout(margin={"r":0,"t":40,"l":0,"b":0}, legend_title_text='Entity Type')
            st.plotly_chart(fig_map, use_container_width=True)
        else:
            st.info("No geographic data available for selected filters.")
    with colv2:
        st.markdown("**Top Sectors**")
        all_sectors = []
        for sectors in filtered_pe['sectors'].dropna():
            all_sectors.extend([s.strip().lower() for s in str(sectors).split(',') if s.strip()])
        sector_counts = Counter(all_sectors)
        sector_df = pd.DataFrame(sector_counts.most_common(10), columns=['Sector', 'Count'])
        fig_sectors = px.bar(sector_df, x='Sector', y='Count', color='Count', color_continuous_scale='viridis', title="Top 10 Sectors")
        fig_sectors.update_xaxes(tickangle=45)
        st.plotly_chart(fig_sectors, use_container_width=True)

    # --- Generate Report Button ---
    st.markdown("---")
    st.markdown("#### Generate and Download Report")
    try:
        from fpdf import FPDF
        import base64
        import tempfile
        import os
        can_pdf = True
    except ImportError:
        can_pdf = False

    def save_plotly_fig_as_png(fig, filename):
        try:
            import plotly.io as pio
            pio.write_image(fig, filename, format='png', width=800, height=400, scale=2)
            return True
        except Exception as e:
            return False

    if can_pdf:
        if st.button("Generate PDF Report"):
            with tempfile.TemporaryDirectory() as tmpdir:
                # Save charts as images
                map_img_path = os.path.join(tmpdir, 'map.png')
                sectors_img_path = os.path.join(tmpdir, 'sectors.png')
                map_img_ok = False
                sectors_img_ok = False
                if fig_map is not None:
                    map_img_ok = save_plotly_fig_as_png(fig_map, map_img_path)
                if fig_sectors is not None:
                    sectors_img_ok = save_plotly_fig_as_png(fig_sectors, sectors_img_path)

                pdf = FPDF()
                pdf.add_page()
                # --- Modern Neutral Header ---
                pdf.set_xy(0, 10)
                pdf.set_font("Arial", 'B', 18)
                pdf.set_text_color(30,30,30)
                pdf.cell(210, 12, "Private Equity Data Report", ln=True, align='C')
                pdf.set_font("Arial", '', 11)
                pdf.set_text_color(80,80,80)
                pdf.cell(210, 8, f"Generated: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M')}", ln=True, align='C')
                pdf.ln(10)
                # --- Executive Summary ---
                pdf.set_font("Arial", 'B', 13)
                pdf.set_text_color(30,30,30)
                pdf.cell(0, 9, "Executive Summary", ln=True)
                pdf.set_font("Arial", '', 11)
                pdf.set_text_color(50,50,50)
                pdf.multi_cell(0, 7, exec_summary if exec_summary else 'N/A')
                pdf.ln(6)
                # --- Key Metrics Table ---
                pdf.set_font("Arial", 'B', 13)
                pdf.set_text_color(30,30,30)
                pdf.cell(0, 9, "Key Metrics", ln=True)
                pdf.set_font("Arial", '', 11)
                pdf.ln(2)
                # Table header
                pdf.set_fill_color(240,240,240)
                pdf.set_draw_color(200,200,200)
                pdf.cell(60, 8, "Metric", 1, 0, 'C', 1)
                pdf.cell(60, 8, "Value", 1, 1, 'C', 1)
                # Table rows
                row_bg = [(255,255,255), (248,248,248)]
                metrics = [
                    ("Total PE Firms", f"{len(filtered_pe):,}"),
                    ("Avg Spanish Companies", f"{avg_spanish:.1f}"),
                    ("Total Divested", f"{total_divested:,}"),
                    ("Active Firms", f"{active_firms:,}")
                ]
                for i, (m, v) in enumerate(metrics):
                    pdf.set_fill_color(*row_bg[i%2])
                    pdf.cell(60, 8, m, 1, 0, 'L', 1)
                    pdf.cell(60, 8, v, 1, 1, 'L', 1)
                pdf.ln(8)
                # --- Top Sectors Table ---
                pdf.set_font("Arial", 'B', 13)
                pdf.set_text_color(30,30,30)
                pdf.cell(0, 9, "Top Sectors", ln=True)
                pdf.set_font("Arial", '', 11)
                pdf.ln(2)
                pdf.set_fill_color(240,240,240)
                pdf.cell(80, 8, "Sector", 1, 0, 'C', 1)
                pdf.cell(40, 8, "Count", 1, 1, 'C', 1)
                for i, row in sector_df.iterrows():
                    pdf.set_fill_color(*row_bg[i%2])
                    pdf.cell(80, 8, row['Sector'].title(), 1, 0, 'L', 1)
                    pdf.cell(40, 8, str(row['Count']), 1, 1, 'L', 1)
                pdf.ln(8)
                # --- PE Firms by Geography Table ---
                pdf.set_font("Arial", 'B', 13)
                pdf.set_text_color(30,30,30)
                pdf.cell(0, 9, "PE Firms by Geography", ln=True)
                pdf.set_font("Arial", '', 11)
                pdf.ln(2)
                geo_counts = geo_map_df['Geography'].value_counts() if not geo_map_df.empty else pd.Series()
                pdf.set_fill_color(240,240,240)
                pdf.cell(80, 8, "Geography", 1, 0, 'C', 1)
                pdf.cell(40, 8, "Count", 1, 1, 'C', 1)
                for i, (geo, count) in enumerate(geo_counts.items()):
                    pdf.set_fill_color(*row_bg[i%2])
                    pdf.cell(80, 8, geo, 1, 0, 'L', 1)
                    pdf.cell(40, 8, str(count), 1, 1, 'L', 1)
                pdf.ln(10)
                # --- Embed Main Charts ---
                if map_img_ok:
                    pdf.set_font("Arial", 'B', 13)
                    pdf.set_text_color(30,30,30)
                    pdf.cell(0, 9, "PE Firms by Geography (Map)", ln=True)
                    pdf.image(map_img_path, w=170)
                    pdf.ln(8)
                if sectors_img_ok:
                    pdf.set_font("Arial", 'B', 13)
                    pdf.set_text_color(30,30,30)
                    pdf.cell(0, 9, "Top Sectors (Chart)", ln=True)
                    pdf.image(sectors_img_path, w=170)
                    pdf.ln(8)
                # --- Footer ---
                pdf.set_y(-20)
                pdf.set_font("Arial", 'I', 10)
                pdf.set_text_color(120, 120, 120)
                pdf.cell(0, 10, "© Private Equity Analytics | Confidential", ln=True, align='C')
                # Download PDF
                pdf_bytes = pdf.output(dest='S').encode('latin1')
                b64 = base64.b64encode(pdf_bytes).decode()
                href = f'<a href="data:application/pdf;base64,{b64}" download="PE_Report.pdf">Download PDF Report</a>'
                st.markdown(href, unsafe_allow_html=True)
                if not (map_img_ok and sectors_img_ok):
                    st.warning("Some charts could not be embedded. For best results, install kaleido: `pip install -U kaleido`")
    else:
        st.warning("PDF generation is not available. Please install fpdf and kaleido: `pip install fpdf kaleido`.")
        if st.button("Generate HTML Report"):
            html = f"""
            <h2 style='text-align:center;background:#FFCC00;padding:10px 0;'>EY Private Equity Data Report</h2>
            <p style='text-align:center;'><b>Generated:</b> {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M')}</p>
            <h3>Executive Summary</h3>
            <p>{exec_summary if exec_summary else 'N/A'}</p>
            <h3>Key Metrics</h3>
            <table border='1' cellpadding='4' cellspacing='0' style='background:#fffbe6;'>
                <tr style='background:#FFCC00;'><th>Metric</th><th>Value</th></tr>
                <tr><td>Total PE Firms</td><td>{len(filtered_pe):,}</td></tr>
                <tr><td>Avg Spanish Companies</td><td>{avg_spanish:.1f}</td></tr>
                <tr><td>Total Divested</td><td>{total_divested:,}</td></tr>
                <tr><td>Active Firms</td><td>{active_firms:,}</td></tr>
            </table>
            <h3>Top Sectors</h3>
            <table border='1' cellpadding='4' cellspacing='0' style='background:#fffbe6;'>
                <tr style='background:#FFCC00;'><th>Sector</th><th>Count</th></tr>
                {''.join([f'<tr><td>{row["Sector"].title()}</td><td>{row["Count"]}</td></tr>' for i, row in sector_df.iterrows()])}
            </table>
            <h3>PE Firms by Geography</h3>
            <table border='1' cellpadding='4' cellspacing='0' style='background:#fffbe6;'>
                <tr style='background:#FFCC00;'><th>Geography</th><th>Count</th></tr>
                {''.join([f'<tr><td>{geo}</td><td>{count}</td></tr>' for geo, count in geo_map_df['Geography'].value_counts().items()])}
            </table>
            <footer style='margin-top:2em;font-size:10px;color:#888;text-align:center;'>© EY Private Equity Analytics | Confidential | Generated {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M')}</footer>
            """
            st.download_button("Download HTML Report", html, "EY_PE_Report.html", "text/html")

    # --- Footer ---
    st.markdown("---")
    st.markdown(f"<div style='text-align:center;font-size:12px;color:#888;'>Report generated on {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M')} &copy; EY Private Equity Analytics</div>", unsafe_allow_html=True)

# --- Drilldown Analytics Tab ---
with tab_drilldown:
    st.title("🔎 Drilldown Analytics")
    st.info("Click on a sector or firm to see detailed analytics and trends. Interactive deep dives for power users.")
    st.markdown("#### Select a Sector to Drill Down")
    sector_list = [s for s, _ in sector_counts.most_common(20)]
    selected_sector = st.selectbox("Sector:", sector_list)
    if selected_sector:
        sector_firms = filtered_pe[filtered_pe['sectors'].fillna('').str.lower().str.contains(selected_sector)]
        st.markdown(f"**PE Firms in {selected_sector.title()}:**")
        st.dataframe(sector_firms[['pe', 'total_spanish_companies', 'total_spanish_divested_companies']], use_container_width=True)
        st.markdown(f"---")
        st.markdown(f"### 🏭 Companies in {selected_sector.title()}: ")
        sector_companies = filtered_companies[filtered_companies['1º_characterization'].fillna('').str.lower().str.contains(selected_sector)]
        display_cols = [col for col in ['company_name', 'owner', 'country'] if col in sector_companies.columns]
        # Sector summary card
        st.markdown(":blue[**Sector Summary**]")
        colA, colB, colC = st.columns(3)
        with colA:
            st.metric("Total PE Firms", len(sector_firms))
        with colB:
            st.metric("Total Companies", len(sector_companies))
        with colC:
            if len(sector_companies) > 0:
                st.plotly_chart(px.histogram(sector_companies, x=display_cols[0] if display_cols else None, title="Company Distribution"), use_container_width=True)
            else:
                st.write(":grey[No company data]")
        # Main company table or fallback
        if len(sector_companies) > 0 and display_cols:
            st.dataframe(sector_companies[display_cols], use_container_width=True)
        else:
            st.warning("No companies found for this sector.\n\n**Possible reasons:**\n- Data quality or missing mapping\n- Spelling/capitalization differences\n- No companies in this sector\n\nTry another sector or check your data.")
            # Demo table for visual interest
            demo_df = pd.DataFrame({
                "company_name": ["DemoCo A", "DemoCo B"],
                "owner": ["Demo PE 1", "Demo PE 2"],
                "country": ["Spain", "UK"]
            })
            st.markdown(":blue[Demo Table:]")
            st.dataframe(demo_df, use_container_width=True)

# --- Upload & Enrich Tab ---
with tab_upload:
    st.title("⬆️ Upload & Enrich")
    st.info("Upload your own Excel/CSV data and get instant analytics. Optionally enrich your data with free external sources.")
    uploaded = st.file_uploader("Upload Excel or CSV file", type=["xlsx", "csv"])
    if uploaded:
        if uploaded.name.endswith(".csv"):
            user_df = pd.read_csv(uploaded)
        else:
            user_df = pd.read_excel(uploaded)
        st.markdown("#### Uploaded Data Preview")
        st.dataframe(user_df.head(20), use_container_width=True)
        st.markdown("#### Quick Stats")
        st.write(user_df.describe(include='all'))
        st.markdown("#### (Demo) Enrichment: Add Country Info")
        if 'company_name' in user_df.columns:
            user_df['Country'] = user_df['company_name'].apply(lambda x: "Spain" if "a" in str(x).lower() else "UK")
            st.dataframe(user_df[['company_name', 'Country']].head(10), use_container_width=True)
        st.success("Demo enrichment complete! (For real enrichment, connect to a free API)")
    else:
        st.info("Upload a file to get started.")
