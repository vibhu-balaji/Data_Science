# app.py — Final Gemini-Powered PE Chatbot with RAG & Q&A

import os
import streamlit as st
import pandas as pd
import joblib
import re
from difflib import get_close_matches
from catboost import CatBoostClassifier
from langchain.vectorstores import Chroma
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.docstore.document import Document
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain_google_genai import ChatGoogleGenerativeAI

import torch.nn.functional as F

from dotenv import load_dotenv
import torch

# Load environment variables
load_dotenv()
# GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

# Load models and data
with st.spinner("Loading model and data..."):
    catboost_model = joblib.load("ML/Supervised/CatBoost.pkl")

pe_df = pd.read_excel("Data/Processed/Cleaned_PE.xlsx")
company_df = pd.read_excel("Data/Processed/outputcheckcombined2.xlsx")
st.success("✅ Models and data loaded.")

# === Helpers ===

def normalize_company_sectors(row):
    cols = ['1º_characterization', '2º_characterization', '3º_characterization',
            '4º_characterization', '5º_characterization', '6º_characterization']
    return [str(row[col]).strip().lower() for col in cols if pd.notna(row[col])]

def embedding_sector_similarity_score(row):
    cs_embeddings = row['sector_embeddings_x']
    ps_embeddings = row['sector_embeddings_y']
    if cs_embeddings is None or ps_embeddings is None:
        return 0
    cosine_scores = cosine_similarity(cs_embeddings, ps_embeddings)
    return cosine_scores.max().item()

def ebitda_match(row):
    try:
        ebitda = float(row.get('ebitda_lya', None))
        min_val = row.get('ticket_ebitda_min', None)
        max_val = row.get('ticket_ebitda_max', None)
        if pd.isna(ebitda): return False
        if pd.notna(min_val) and pd.notna(max_val): return min_val <= ebitda <= max_val
        if pd.notna(min_val): return ebitda >= min_val
        if pd.notna(max_val): return ebitda <= max_val
        return False
    except: return False

def build_pe_list_string(top_matches_df):
    lines = []
    for _, row in top_matches_df.iterrows():
        line = f"- {row['pe']}: Match Probability {row['match_probability']:.2f}, Sector Similarity {row['sector_similarity_score']:.2f}, "
        line += f"EBITDA Match {'Yes' if row['ebitda_in_range'] else 'No'}, Spanish Companies: {int(row['total_spanish_companies'])}"
        lines.append(line)
    return "\n".join(lines)

def pe_firm_to_text(row):
    return f"""Firm: {row['pe']}
Sectors: {row.get('sectors', 'N/A')}
Top Geographies: {row.get('top_geographies', 'N/A')}
Total Spanish Companies: {row.get('total_spanish_companies', 'N/A')}
Total Spanish Divested Companies: {row.get('total_spanish_divested_companies', 'N/A')}"""

pe_chunks = pe_df.apply(pe_firm_to_text, axis=1).tolist()
documents = [Document(page_content=chunk, metadata={}) for chunk in pe_chunks]
vectorstore = Chroma.from_documents(documents, embedding_model)
retriever = vectorstore.as_retriever(search_kwargs={"k": 10})

# === LLM + Prompts ===
llm = ChatGoogleGenerativeAI(model="gemini-2.5-pro", temperature=0.2)

qa_rag_prompt = PromptTemplate.from_template("""
You are a Private Equity expert answering an EY consultant's question.

Context:
- Company: {company_name}
- Sector: {company_sector}
- EBITDA: EUR {company_ebitda}M
- Selected PE firms: {pe_list}

Background Information:
{retrieved_context}

Conversation history:
{chat_history}

Latest question:
{user_question}

Respond clearly in bullet points, one per PE firm, including their match probability and rationale.
Avoid introductory or closing statements unless they are essential.
""")
qa_rag_chain = LLMChain(llm=llm, prompt=qa_rag_prompt)

# === Prediction ===
def predict_top_pes(company_name, top_n=10):
    selected = company_df[company_df["company_name"].str.lower() == company_name.lower()]
    if selected.empty: return None, "❌ Company not found."
    selected["key"] = 1
    pe_copy = pe_df.copy(); pe_copy["key"] = 1
    df = selected.merge(pe_copy, on="key").drop("key", axis=1)
    df["total_spanish_companies"] = df["total_spanish_companies"].fillna(0)
    df["normalized_sectors_x"] = df.apply(normalize_company_sectors, axis=1)
    df["normalized_sectors_y"] = df["sectors"].fillna('').apply(lambda x: [s.strip().lower() for s in x.split(",") if s])
    df["sector_embeddings_x"] = df["normalized_sectors_x"].apply(sbert_model.encode)
    df["sector_embeddings_y"] = df["normalized_sectors_y"].apply(sbert_model.encode)
    df["sector_similarity_score"] = df.apply(embedding_sector_similarity_score, axis=1)
    df["ebitda_in_range"] = df.apply(ebitda_match, axis=1)
    df["match_probability"] = catboost_model.predict_proba(
        df[["sector_similarity_score", "ebitda_in_range", "total_spanish_companies"]])[:, 1]
    return df.sort_values("match_probability", ascending=False).head(top_n), None

# === Streamlit Chat UI ===
st.title("💼 Ask the PE Chatbot")

if "messages" not in st.session_state:
    st.session_state.messages = []

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

user_input = st.chat_input("Ask which PE firm might acquire a company...")

if user_input:
    with st.chat_message("user"):
        st.markdown(user_input)
    st.session_state.messages.append({"role": "user", "content": user_input})

    # Clean and fuzzy match company name
    company_df = company_df[company_df["company_name"].notna()].copy()
    company_df["__clean__"] = company_df["company_name"].astype(str).str.lower().str.strip()
    clean_names = company_df["__clean__"].tolist()

    user_clean = user_input.lower().strip()
    input_tokens = re.findall(r'\b\w+\b', user_clean)

    candidates = get_close_matches(user_clean, clean_names, n=1, cutoff=0.6)
    if not candidates:
        for token in input_tokens:
            token_matches = get_close_matches(token, clean_names, n=1, cutoff=0.8)
            if token_matches:
                candidates = token_matches
                break

    if not candidates:
        response = "❌ I couldn't recognize a valid company in your message. Please, try typing the full company name."
    else:
        matched_name = company_df[company_df["__clean__"] == candidates[0]]["company_name"].iloc[0]
        top_df, error = predict_top_pes(matched_name, top_n=10)
        if error:
            response = error
        else:
            top_df = top_df.head(10)
            pe_list = build_pe_list_string(top_df)
            top_pe_names = top_df["pe"].tolist()
            query = " ".join(top_pe_names)
            retrieved_docs = retriever.get_relevant_documents(query)
            retrieved_text = "\n\n".join([doc.page_content for doc in retrieved_docs])
            chat_history_str = "\n".join(
                [f"User: {m['content']}" for m in st.session_state.messages if m["role"] == "user"]
            )
            qa_inputs = {
                "company_name": matched_name,
                "company_sector": ", ".join(top_df.iloc[0]["normalized_sectors_x"]),
                "company_ebitda": top_df.iloc[0]["ebitda_lya"],
                "pe_list": pe_list,
                "retrieved_context": retrieved_text,
                "chat_history": chat_history_str,
                "user_question": user_input
            }
            response = qa_rag_chain.run(qa_inputs)

    with st.chat_message("assistant"):
        st.markdown(response)
        # --- Feedback section ---
        st.markdown("#### Was this answer helpful?")
        col1, col2 = st.columns([1, 1])
        with col1:
            if st.button("👍 Yes", key=f"yes_{len(st.session_state.messages)}"):
                st.success("Thanks for your feedback!")
            # Optionally log: save_feedback(matched_name, user_input, response, "positive")
        with col2:
            if st.button("👎 No", key=f"no_{len(st.session_state.messages)}"):
                st.warning("Thanks — we'll use that to improve.")
            # Optionally log: save_feedback(matched_name, user_input, response, "negative")
    st.session_state.messages.append({"role": "assistant", "content": response})
        with col2:
            if st.button("👎 No", key=f"no_{len(st.session_state.messages)}"):
                st.warning("Thanks — we'll use that to improve.")
            # Optionally log: save_feedback(matched_name, user_input, response, "negative")
    st.session_state.messages.append({"role": "assistant", "content": response})
