# PEquity – Private Equity Matchmaker

## Overview

In a competitive Private Equity (PE) landscape where deal origination speed and strategic alignment are more critical than ever, identifying the right buyer for a company remains an inherently complex and resource-intensive process. **PEquity** is a data-driven tool developed to help EY Parthenon analysts streamline the process of matching acquisition targets with the most relevant PE buyers using machine learning and natural language interaction.

Developed exclusively for the Spanish market, the solution leverages EY's proprietary data on PE firms, portfolio companies, and historical transactions to recommend the five most likely acquirers for any given Spanish company. This tool enhances analyst productivity and improves outreach strategies by automating what is traditionally a manual screening process.

## 🚀 Key Features

- **PE Match Recommendations**: Predicts top 5 most likely PE buyers for a target company
- **Machine Learning Engine**: Based on sector, deal size, geography, and behavioral patterns
- **LLM-Powered Interface**: Simple natural language prompts via a conversational UI powered by Google Gemini
- **Strategic Insight**: Surfaces patterns like sector bias, ticket size preferences, and regional focus
- **Speed and Precision**: Reduces manual effort, supports faster and smarter outreach
- **Market-Ready**: Initially designed for Spain with potential for broader expansion
- **Interactive Analytics**: Drill-down capabilities and comprehensive reporting
- **Data Upload & Enrichment**: Ability to upload and analyze new company data

## 📁 Project Structure

```
mbd-corporateproject-EY-main_Updated/
├── Application/                    # Streamlit-based user interface
│   ├── app4.py                    # Main application (latest version)
│   ├── LLM_currentversion2.ipynb  # LLM development notebook
│   ├── requirements_app4.txt      # Dependencies for main app
│   ├── requirements_app4_no_chroma.txt  # Dependencies without ChromaDB
├── Data/                          # Source data and processed datasets
│   ├── Processed/                 # Cleaned and processed data
│   │   ├── Cleaned_PE.xlsx        # Processed PE firm data
│   │   ├── outputcheckcombined2.xlsx  # Combined company data
│   │   └── PE_Transactions.xlsx   # Transaction history
│   └── Raw/                       # Original source data
│       ├── CPR_Summary(Last).xlsx
│       ├── EYP_Education_Summary.xlsx
│       └── EYP_PE_BDD_v2.xlsx
├── Data Cleaning/                 # Data preparation scripts
│   └── V5.ipynb                   # Data cleaning notebook
├── EDA/                          # Exploratory Data Analysis
│   ├── Company_EDA.ipynb          # Company data analysis
│   └── PE_EDA.ipynb               # PE firm analysis
├── ML/                           # Machine Learning models
│   ├── Supervised/                # Supervised learning approaches
│   │   ├── CatBoost.ipynb         # CatBoost model development
│   │   ├── CatBoost.pkl           # Trained CatBoost model
│   │   ├── RandomForest.ipynb     # Random Forest model
│   │   └── XGBoost.ipynb          # XGBoost model
│   └── Unsupervised/              # Unsupervised learning approaches
└── README.md                      # Project documentation
```

## 🛠️ Technology Stack

### Core Technologies
- **Python 3.8+**: Primary programming language
- **Streamlit**: Web application framework
- **Google Gemini 2.5 Pro**: Large Language Model for natural language processing
- **CatBoost**: Gradient boosting algorithm for predictions
- **Sentence Transformers**: Semantic similarity calculations

### Key Libraries
- **pandas & numpy**: Data manipulation and analysis
- **langchain**: LLM integration and RAG implementation
- **plotly**: Interactive visualizations
- **networkx**: Network analysis and graph visualization
- **chromadb**: Vector database for similarity search
- **joblib**: Model serialization and loading

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- Google API key for Gemini access
- Required data files in the Data/Processed/ directory

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd mbd-corporateproject-EY-main_Updated
   ```

2. **Install dependencies**
   ```bash
   cd Application
   pip install -r requirements_app4.txt
   ```

3. **Set up environment variables**
   Create a `.env` file in the Application directory:
   ```
   GOOGLE_API_KEY=your_google_api_key_here
   ```

4. **Run the application**
   ```bash
   streamlit run app4.py
   ```

### Data Requirements
Ensure the following files are present in the `Data/Processed/` directory:
- `Cleaned_PE.xlsx`: Processed PE firm data
- `outputcheckcombined2.xlsx`: Combined company data
- `PE_Transactions.xlsx`: Transaction history

## 💡 How It Works

### 1. Data Integration
The system combines three key EY proprietary datasets:
- **PE Firms Data**: Information about private equity firms, their sectors, geographies, and investment patterns
- **Portfolio Companies**: Historical portfolio companies and their characteristics
- **Transaction History**: Past deals and their details

### 2. Machine Learning Pipeline
- **Feature Engineering**: Sector similarity, EBITDA matching, geographic alignment
- **Model Training**: Multiple supervised learning approaches tested (CatBoost, XGBoost, Random Forest)
- **Model Selection**: CatBoost selected for best performance and interpretability
- **Prediction Engine**: Generates probability scores for PE firm matches

### 3. Natural Language Interface
- **LLM Integration**: Google Gemini 2.5 Pro for understanding user queries
- **RAG Implementation**: Retrieval-Augmented Generation for context-aware responses
- **Conversational UI**: Streamlit-based chat interface with multiple tabs

### 4. Interactive Features
- **Chatbot Tab**: Natural language queries and responses
- **Explorer Tab**: Data exploration and visualization
- **Report Tab**: Generated reports and insights
- **Drilldown Analytics**: Detailed analysis capabilities
- **Upload & Enrich**: Data upload and enrichment functionality

## 📊 Model Performance

The system uses a **CatBoost classifier** trained on historical transaction data with the following features:
- Sector similarity scores (using sentence embeddings)
- EBITDA range matching
- Geographic alignment
- Historical investment patterns
- Firm size and investment capacity

## 🎯 Example Usage

### Natural Language Queries
```
"Which PEs are most likely to acquire a €50M revenue FMCG company in Madrid?"
"Find PE firms that invest in technology companies with €20-100M EBITDA"
"Show me PE firms with experience in the healthcare sector in Spain"
```

### Expected Output
The system provides:
1. **Top 5 PE Recommendations** with match probabilities
2. **Detailed Analysis** including sector similarity and EBITDA matching
3. **Strategic Insights** about each firm's investment patterns
4. **Interactive Visualizations** of relationships and patterns

## 🔧 Configuration

### Model Parameters
- **Top N Recommendations**: Configurable (default: 5)
- **Similarity Threshold**: Minimum similarity score for recommendations
- **EBITDA Matching**: Strict vs. flexible matching criteria

### LLM Settings
- **Temperature**: 0.2 (for consistent responses)
- **Model**: Gemini 2.5 Pro
- **Context Window**: Optimized for PE-specific queries

## 📈 Business Impact

- **Time Saved**: Reduces buyer screening from hours to seconds
- **Improved Targeting**: Enhances hit rate in buyer outreach
- **Competitive Advantage**: Leverages ML to gain edge in M&A advisory
- **Data-Driven Decisions**: Provides quantitative backing for recommendations

## 🔮 Future Roadmap

### Short-term (Next 3 months)
- [ ] Final model calibration and validation
- [ ] Performance optimization and caching
- [ ] Enhanced error handling and logging
- [ ] User feedback integration

### Medium-term (3-6 months)
- [ ] Expansion to new geographies (Europe, Americas)
- [ ] Integration with CRM tools
- [ ] Real-time data ingestion pipeline
- [ ] Advanced analytics dashboard

### Long-term (6+ months)
- [ ] Multi-language support
- [ ] API development for third-party integration
- [ ] Advanced ML models (deep learning, ensemble methods)
- [ ] Mobile application development

## 🤝 Contributing

This project is developed for EY Parthenon's internal use. For questions or contributions, please contact the development team.

## 📄 License

This project is proprietary to EY Parthenon and contains confidential business information.

## 🆘 Troubleshooting

### Common Issues

1. **Model Loading Errors**
   - Ensure `CatBoost.pkl` is present in `ML/Supervised/`
   - Check Python version compatibility

2. **Data Loading Errors**
   - Verify all required Excel files are in `Data/Processed/`
   - Check file permissions and paths

3. **API Key Issues**
   - Ensure Google API key is valid and has Gemini access
   - Check `.env` file format and location

4. **Memory Issues**
   - Consider using `requirements_app4_no_chroma.txt` for lighter installation
   - Increase system memory allocation if needed

### Support
For technical support or questions about the implementation, please refer to the development team or check the Jupyter notebooks in the respective directories for detailed implementation notes.

